cd GoldenCheetah
QT_BIN=${HOME}/dev/Qt5.5.1/5.5/gcc_64/bin
make distclean
git checkout master
git reset --hard HEAD~5
git pull
GC_COMMIT=`git rev-parse HEAD | cut -c 1-10`
git checkout ${GC_COMMIT}
export GC_DATE=`git log -1 --date=iso --format=fuller | egrep ^CommitDate | cut -c 13-22`
export GC_INFO=${GC_DATE}':master@'${GC_COMMIT}
cp qwt/qwtconfig.pri.in qwt/qwtconfig.pri
cp src/gcconfig.pri.in src/gcconfig.pri
cat << EOF >> src/gcconfig.pri
DEFINES += GC_VERSION=\\\\\"${GC_INFO}\\\\\"
EOF
sed -i "s|#\(CONFIG += release.*\)|\1 static|" src/gcconfig.pri
sed -i "s|#\(QMAKE_LRELEASE = \).*|\1 ${QT_BIN}/lrelease|" src/gcconfig.pri
sed -i "s|^#QMAKE_CXXFLAGS|QMAKE_CXXFLAGS|" src/gcconfig.pri
sed -i "s|#\(SRMIO_INSTALL =.*\)|\1 ../../usr|" src/gcconfig.pri
sed -i "s|#\(D2XX_INCLUDE =.*\)|\1 ../../usr/include|" src/gcconfig.pri
sed -i "s|#\(QWT3D_INSTALL =.*\)|\1 ../../qwtplot3d|" src/gcconfig.pri
sed -i "s|#\(KML_INSTALL =\).*|\1 ../../usr|" src/gcconfig.pri
sed -i "s|#\(ICAL_INSTALL =.*\)|\1 ../../usr|" src/gcconfig.pri
sed -i "s|#\(ICAL_LIBS    =.*\)|\1 ../../usr/lib/libical.a|" src/gcconfig.pri
sed -i "s|#\(LIBUSB_INSTALL =\).*|\1 ../../usr|" src/gcconfig.pri
sed -i "s|#\(LIBUSB_LIBS    =.*\)|\1 ../../usr/lib/libusb.a -lusb-1.0 -ldl -ludev|" src/gcconfig.pri
sed -i "s|#\(VLC_INSTALL =.*\)|\1 /usr|" src/gcconfig.pri
sed -i "s|#\(VLC_LIBS    =.*\)|\1 -lvlc -lvlccore|" src/gcconfig.pri
sed -i "s|#\(SAMPLERATE_INSTALL =\).*|\1 /usr|" src/gcconfig.pri
sed -i "s|#\(SAMPLERATE_LIBS =\).*|\1 -lsamplerate|" src/gcconfig.pri
sed -i "s|^#LIBZ_LIBS|LIBZ_LIBS|" src/gcconfig.pri
sed -i "s|^#HTPATH|HTPATH|" src/gcconfig.pri
sed -i "s|^#CloudDB|CloudDB|" src/gcconfig.pri
sed -i "s|\(DEFINES += GC_VIDEO_NONE.*\)|#\1 |" src/gcconfig.pri
sed -i "s|#\(DEFINES += GC_VIDEO_VLC.*\)|\1|" src/gcconfig.pri
sed -i "s|#\(DEFINES += GC_WANT_R.*\)|\1 |" src/gcconfig.pri
sed -i "s/__GC_GOOGLE_CALENDAR_CLIENT_SECRET__/dnDYzTOUEqHbrJ4F1LA_3RZb/" src/Core/Secrets.h
sed -i "s/__GC_STRAVA_CLIENT_SECRET__/378b13d79308655b239f79ee4e6095db5365dd06/" src/Core/Secrets.h
sed -i "s/__GC_DROPBOX_CLIENT_SECRET__/y2lcfn4wiwquzpf/" src/Core/Secrets.h
sed -i "s/__GC_CYCLINGANALYTICS_CLIENT_SECRET__/QQqjIvvCQR3MGID1TiJGGPLIIF4IfaG30MsxQ0tA/" src/Core/Secrets.h
sed -i "s/__GC_TWITTER_CONSUMER_SECRET__/IWXu2G6mQC5xvhM8V0ohA0mPTUOqAFutiuKIva3LQg/" src/Core/Secrets.h
sed -i "s/__GC_CLOUD_DB_BASIC_AUTH__/AktGK7nn6VJ6Hd5Xd5X8B4XliMtLuf7oAkgxcDgS/" src/Core/Secrets.h
sed -i "s/__GC_CLOUD_DB_APP_NAME__/gcclouddb1e8s5r7m/" src/Core/Secrets.h
${QT_BIN}/lupdate src/src.pro
${QT_BIN}/qmake -recursive
make -j3
git checkout master
git reset --hard HEAD~5
git pull
cd ..
