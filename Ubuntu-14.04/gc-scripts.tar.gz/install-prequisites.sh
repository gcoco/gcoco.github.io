sudo apt-get install -qq build-essential cmake flex bison git chrpath
#sudo apt-get install -qq qt5-default qttools5-dev-tools
#sudo apt-get install -qq libqt5svg5-dev qtmultimedia5-dev libqt5serialport5-dev libqt5webkit5-dev
sudo apt-get install -qq libssl-dev libusb-1.0-0-dev libudev-dev libsamplerate0-dev
sudo apt-get install -qq libvlc-dev libvlccore-dev
sudo apt-get install -qq r-base-dev
sudo apt-get install -qq libglu1-mesa-dev
