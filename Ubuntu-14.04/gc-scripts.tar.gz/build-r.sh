# R build
sudo apt-get install r-base r-base-dev
mkdir temp-r && cd temp-r
R CMD BATCH GoldenCheetah/util/install-packages.R
git clone --depth=1 https://github.com/eddelbuettel/rinside.git RInside
sed -i "s|\/\/\ \#define|\#define|" RInside/inst/include/RInsideConfig.h
R CMD INSTALL RInside
cd ..
rm -rf temp-r
