#!/bin/bash

rm -rf release-deb
cp -R deb-build release-deb
cp GoldenCheetah/src/GoldenCheetah release-deb/opt/GoldenCheetah/
cp GoldenCheetah/src/Resources/linux/51-garmin-usb.rules release-deb/etc/udev/rules.d/
chrpath -r "\$ORIGIN:\$ORIGIN/lib" release-deb/opt/GoldenCheetah/GoldenCheetah
chmod 755 release-deb/opt/GoldenCheetah/GoldenCheetah
export SIZE=`ls -l --block-size=1kB GoldenCheetah/src/GoldenCheetah | cut -d " " -f5`
sed -i 's/SIZE/'"$SIZE"'/g' release-deb/DEBIAN/control
VERSION="4.0.0dev+`date +%Y%m%d`"
sed -i 's/VERSION/'"$VERSION"'/g' release-deb/DEBIAN/control
cat release-deb/DEBIAN/control
dpkg -b release-deb/ GoldenCheetah_${VERSION}_Qt5.5.1_amd64.deb
dpkg -c GoldenCheetah_${VERSION}_Qt5.5.1_amd64.deb
