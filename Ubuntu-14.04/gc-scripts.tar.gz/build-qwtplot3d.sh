# QWTPLOT3D build
QT_BIN=${HOME}/dev/Qt5.5.1/5.5/gcc_64/bin
git clone --depth 1 https://github.com/sintegrial/qwtplot3d.git qwtplot3d
cd qwtplot3d
sed -i "s|examples||" qwtplot3d.pro
${QT_BIN}/qmake -recursive
make -j3
